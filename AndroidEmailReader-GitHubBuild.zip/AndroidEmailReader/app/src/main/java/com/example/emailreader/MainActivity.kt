package com.example.emailreader

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.mail.*
import javax.mail.internet.InternetAddress
import java.util.Properties
import kotlin.concurrent.thread

data class MailAccount(
    val email: String,
    val password: String,
    val server: String,
    val protocol: String = "IMAPS"
)

class MainActivity : Activity() {
    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var serverField: EditText
    private lateinit var protocolSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var accountList: LinearLayout
    private lateinit var output: TextView
    private val accounts = mutableListOf<MailAccount>()
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var autoRefresh = false

    private val refreshTask = object : Runnable {
        override fun run() {
            if (autoRefresh) {
                readAllInboxes()
                handler.postDelayed(this, 30_000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadAccounts()
        buildUi()
        renderAccounts()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 16)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply { text = "Multi-Account Email Tester"; textSize = 24f })
        content.addView(TextView(this).apply {
            text = "Add accounts manually or import a CSV/TXT file. Each listed account is tested once when you press Test All."
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })

        emailField = edit("Email address")
        passwordField = edit("Password or provider app password", true)
        serverField = edit("Incoming server (e.g. imap.gmail.com)")
        protocolSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("IMAPS", "POP3S"))
        }
        content.addView(emailField)
        content.addView(passwordField)
        content.addView(serverField)
        content.addView(protocolSpinner)
        content.addView(button("Add account") { addAccount() })
        content.addView(button("Import CSV / TXT") { chooseFile() })
        content.addView(button("Test all accounts") { testAllAccounts() })
        content.addView(button("Read all inboxes") { readAllInboxes() })
        content.addView(button("Enable / disable 30-second checks") { toggleRefresh() })
        status = TextView(this).apply { text = "Ready"; textSize = 14f; setPadding(0, 12, 0, 12) }
        content.addView(status)
        content.addView(TextView(this).apply { text = "ACCOUNTS"; textSize = 18f })
        accountList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(accountList)
        output = TextView(this).apply { text = "Messages will appear here."; textSize = 13f; setPadding(0, 16, 0, 16) }
        content.addView(output)
        content.addView(TextView(this).apply {
            text = "CSV columns: email,password,server,protocol. Protocol can be IMAPS or POP3S. Use a server supplied by your email provider. Import only accounts you own or are authorized to test."
            textSize = 12f
            setPadding(0, 16, 0, 16)
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun edit(hintText: String, secret: Boolean = false) = EditText(this).apply {
        hint = hintText
        singleLine = true
        if (secret) inputType = 129
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun addAccount() {
        val email = emailField.text.toString().trim()
        val password = passwordField.text.toString()
        val server = serverField.text.toString().trim()
        val protocol = protocolSpinner.selectedItem.toString()
        if (email.isBlank() || password.isBlank() || server.isBlank()) {
            status.text = "Enter an email, password and incoming server."
            return
        }
        if (accounts.any { it.email.equals(email, true) }) {
            status.text = "That email is already in the list. Remove it first to replace it."
            return
        }
        accounts.add(MailAccount(email, password, server, protocol))
        saveAccounts()
        renderAccounts()
        emailField.text.clear(); passwordField.text.clear(); serverField.text.clear()
        status.text = "Added $email"
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
        }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Deprecated by platform; kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val rows = parseCsv(text)
                var added = 0
                rows.forEachIndexed { index, row ->
                    if (row.size >= 3) {
                        val email = row[0].trim()
                        val password = row[1]
                        val server = row[2].trim()
                        val protocol = row.getOrNull(3)?.trim()?.uppercase()?.ifBlank { "IMAPS" } ?: "IMAPS"
                        if (index == 0 && email.equals("email", true)) return@forEachIndexed
                        if (email.isNotBlank() && password.isNotBlank() && server.isNotBlank() &&
                            protocol in listOf("IMAPS", "POP3S") && accounts.none { it.email.equals(email, true) }) {
                            accounts.add(MailAccount(email, password, server, protocol)); added++
                        }
                    }
                }
                saveAccounts(); renderAccounts()
                status.text = "Imported $added account(s). Duplicate or invalid rows were skipped."
            } catch (e: Exception) {
                status.text = "Import failed: ${e.message}"
            }
        }
    }

    // Handles quoted CSV fields and escaped double quotes.
    private fun parseCsv(input: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < input.length) {
            val c = input[i]
            when {
                c == '"' && quoted && i + 1 < input.length && input[i + 1] == '"' -> { cell.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { row.add(cell.toString()); cell.setLength(0) }
                (c == '\n' || c == '\r') && !quoted -> {
                    if (c == '\r' && i + 1 < input.length && input[i + 1] == '\n') i++
                    row.add(cell.toString()); cell.setLength(0)
                    if (row.any { it.isNotBlank() }) rows.add(row)
                    row = mutableListOf()
                }
                else -> cell.append(c)
            }
            i++
        }
        row.add(cell.toString())
        if (row.any { it.isNotBlank() }) rows.add(row)
        return rows
    }

    private fun renderAccounts() {
        accountList.removeAllViews()
        if (accounts.isEmpty()) accountList.addView(TextView(this).apply { text = "No accounts added yet." })
        accounts.forEachIndexed { index, account ->
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(8, 12, 8, 12)
            }
            panel.addView(TextView(this).apply {
                text = "${account.email}\n${account.protocol} • ${account.server}"
                textSize = 15f
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            actions.addView(Button(this).apply {
                text = "Test"
                setOnClickListener { testAccount(index) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(Button(this).apply {
                text = "Read"
                setOnClickListener { readAccount(index) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(Button(this).apply {
                text = "Remove"
                setOnClickListener { accounts.removeAt(index); saveAccounts(); renderAccounts(); status.text = "Account removed." }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            panel.addView(actions)
            accountList.addView(panel)
            accountList.addView(View(this).apply {
                setBackgroundColor(0xFFDDDDDD.toInt())
                layoutParams = LinearLayout.LayoutParams(-1, 1)
            })
        }
    }

    private fun toggleRefresh() {
        autoRefresh = !autoRefresh
        handler.removeCallbacks(refreshTask)
        if (autoRefresh) {
            status.text = "Automatic checks enabled while this app is open."
            handler.post(refreshTask)
        } else status.text = "Automatic checks disabled."
    }

    private fun testAllAccounts() {
        if (accounts.isEmpty()) { status.text = "Add or import accounts first."; return }
        status.text = "Testing ${accounts.size} account(s), one connection per account..."
        val snapshot = accounts.toList()
        thread {
            val results = snapshot.map { account -> account.email to testConnection(account) }
            runOnUiThread {
                status.text = results.joinToString("\n") { (email, result) -> "$email: $result" }
            }
        }
    }

    private fun readAllInboxes() {
        if (accounts.isEmpty()) { status.text = "Add or import accounts first."; return }
        val snapshot = accounts.toList()
        status.text = "Reading inboxes..."
        thread {
            val report = snapshot.joinToString("\n\n") { account ->
                "===== ${account.email} =====\n" + readRecentMessages(account)
            }
            runOnUiThread {
                output.text = report
                status.text = "Inbox check completed for ${snapshot.size} account(s)."
            }
        }
    }

    private fun readAccount(index: Int) {
        if (index !in accounts.indices) return
        val account = accounts[index]
        status.text = "Reading ${account.email}..."
        thread {
            val report = readRecentMessages(account)
            runOnUiThread {
                output.text = "===== ${account.email} =====\n$report"
                status.text = "Finished reading ${account.email}."
            }
        }
    }

    private fun readRecentMessages(account: MailAccount): String {
        var store: Store? = null
        try {
            val protocol = if (account.protocol == "POP3S") "pop3s" else "imaps"
            val props = Properties().apply {
                put("mail.store.protocol", protocol)
                put("mail.$protocol.host", account.server)
                put("mail.$protocol.port", if (protocol == "pop3s") "995" else "993")
                put("mail.$protocol.ssl.enable", "true")
                put("mail.$protocol.ssl.checkserveridentity", "true")
                put("mail.$protocol.connectiontimeout", "12000")
                put("mail.$protocol.timeout", "12000")
            }
            store = Session.getInstance(props).getStore(protocol)
            store.connect(account.server, if (protocol == "pop3s") 995 else 993, account.email, account.password)
            val inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_ONLY)
            val messages = inbox.messages
            val first = (messages.size - 10).coerceAtLeast(0)
            val lines = mutableListOf<String>()
            for (i in messages.size - 1 downTo first) {
                val msg = messages[i]
                val sender = (msg.from?.firstOrNull() as? InternetAddress)?.address ?: "Unknown sender"
                val body = extractPlainText(msg).take(500)
                lines.add("From: $sender\nSubject: ${msg.subject ?: "(No subject)"}\nDate: ${msg.sentDate ?: ""}\n$body")
            }
            inbox.close(false)
            store.close()
            return if (lines.isEmpty()) "No messages found." else lines.joinToString("\n\n--------------------\n\n")
        } catch (e: Exception) {
            try { store?.close() } catch (_: Exception) {}
            return "Could not read inbox: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun extractPlainText(part: Part): String {
        return try {
            if (part.isMimeType("text/plain")) part.content.toString()
            else if (part.isMimeType("multipart/*")) {
                val multi = part.content as Multipart
                (0 until multi.count).mapNotNull { idx ->
                    val child = multi.getBodyPart(idx)
                    if (child.isMimeType("text/plain") || child.isMimeType("multipart/*")) extractPlainText(child) else null
                }.joinToString("\n")
            } else ""
        } catch (_: Exception) { "" }
    }

    private fun testAccount(index: Int) {
        if (index !in accounts.indices) return
        val account = accounts[index]
        status.text = "Testing ${account.email}..."
        thread {
            val result = testConnection(account)
            runOnUiThread { status.text = "${account.email}: $result" }
        }
    }

    private fun testConnection(account: MailAccount): String {
        var store: Store? = null
        try {
            val protocol = if (account.protocol == "POP3S") "pop3s" else "imaps"
            val props = Properties().apply {
                put("mail.store.protocol", protocol)
                put("mail.$protocol.host", account.server)
                put("mail.$protocol.port", if (protocol == "pop3s") "995" else "993")
                put("mail.$protocol.ssl.enable", "true")
                put("mail.$protocol.ssl.checkserveridentity", "true")
                put("mail.$protocol.connectiontimeout", "12000")
                put("mail.$protocol.timeout", "12000")
            }
            val session = Session.getInstance(props)
            store = session.getStore(protocol)
            store.connect(account.server,
                if (protocol == "pop3s") 995 else 993,
                account.email, account.password)
            val folder = if (protocol == "imaps") store.getFolder("INBOX") else null
            if (folder != null) folder.open(Folder.READ_ONLY)
            val count = folder?.messageCount
            folder?.close(false)
            store.close()
            return if (count != null) "SUCCESS — inbox has $count message(s)" else "SUCCESS — POP3S login accepted"
        } catch (e: Exception) {
            try { store?.close() } catch (_: Exception) {}
            return "FAILED — ${e.message ?: e.javaClass.simpleName}"
        }
    }

    // Encrypts the complete account list with an Android Keystore AES-GCM key.
    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey("EmailReaderKey", null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("EmailReaderKey",
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun saveAccounts() {
        try {
            val array = JSONArray()
            accounts.forEach { a -> array.put(JSONObject().put("email", a.email).put("password", a.password)
                .put("server", a.server).put("protocol", a.protocol)) }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.doFinal(array.toString().toByteArray(Charsets.UTF_8))
            val packed = cipher.iv + encrypted
            getSharedPreferences("secure_accounts", MODE_PRIVATE).edit()
                .putString("accounts", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
        } catch (e: Exception) {
            status.text = "Could not securely save accounts: ${e.message}"
        }
    }

    private fun loadAccounts() {
        try {
            val encoded = getSharedPreferences("secure_accounts", MODE_PRIVATE).getString("accounts", null) ?: return
            val packed = Base64.decode(encoded, Base64.NO_WRAP)
            val iv = packed.copyOfRange(0, 12)
            val encrypted = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            val array = JSONArray(String(cipher.doFinal(encrypted), Charsets.UTF_8))
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                accounts.add(MailAccount(item.getString("email"), item.getString("password"),
                    item.getString("server"), item.optString("protocol", "IMAPS")))
            }
        } catch (_: Exception) {
            accounts.clear()
        }
    }

    override fun onDestroy() {
        autoRefresh = false
        handler.removeCallbacks(refreshTask)
        super.onDestroy()
    }
}
